#ifndef L293D_H
#define L293D_H

#include "pololuMD08A.h"

typedef PololuMD08A L293D;

#endif //L293D_H
